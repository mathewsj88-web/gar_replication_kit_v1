# TODO: implement compute_ddi(df, params)
