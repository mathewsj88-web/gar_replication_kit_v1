# TODO: implement compute_gar(df, params)
