# Falsifiers (Red-Team Summary)

- After standard factor controls, GAR does not predict realized drawdowns.
- GAR month-to-month autocorrelation ≈ 0.
- DDI correlates ≥ 0.7 with simple volatility or turnover (i.e., redundant).
- Independent replication cannot match headline values within tolerances.
