# Citation

Mathews, J. (2025). *The Governance Adherence Ratio: Quantifying Discipline Behavior.* SSRN Paper No. XXXXXX.  
Osiris Research LLC.
