# Osiris Research — Contributor License Agreement (CLA)

By contributing code, data, or documentation (“Contribution”) to this repository, you agree:

1. You own or have the right to license the Contribution.
2. You grant **Osiris Research LLC** a perpetual, worldwide, royalty-free license to use, reproduce, modify, and distribute your Contribution **within the Osiris Research projects**, including future closed or commercial versions.
3. You retain copyright to your Contribution.
4. You warrant your Contribution does not knowingly infringe third-party rights.
5. Contributions are provided “AS IS” without warranties.
6. This CLA does **not** grant you rights to Osiris proprietary IP beyond the repository’s LICENSE.

If you cannot agree, do not submit a Contribution.
